/*
 * Copyright (c) 2025 lax1dude, ayunami2000. All Rights Reserved.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 * NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 * 
 */

package net.lax1dude.eaglercraft.v1_8.voice;

import net.lax1dude.eaglercraft.v1_8.EaglercraftUUID;

public class VoicePlayerState {

	public final VoiceClientInstance client;
	public final EaglercraftUUID uuid;
	public long lastRequest = -15000l;
	public String name = null;
	public boolean nearby = false;

	public VoicePlayerState(VoiceClientInstance client, EaglercraftUUID uuid) {
		this.client = client;
		this.uuid = uuid;
	}

	public void tryRequest(long millis) {
		if (!VoiceClientController.getVoiceListening().contains(uuid)) {
			if (millis - lastRequest > 4000l) {
				lastRequest = millis;
				client.sendPacketRequest(this);
			}
		}
	}

	public void handleDisconnect() {
		lastRequest = 0l;
	}

	public boolean isListening() {
		return VoiceClientController.getVoiceListening().contains(uuid);
	}

}
